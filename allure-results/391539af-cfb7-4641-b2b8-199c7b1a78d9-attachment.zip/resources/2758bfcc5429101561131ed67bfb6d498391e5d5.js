// Ad Tracking JavaScript
var AdTracking = (function() {
    var trackingEndpoint = '/2db/ad_tracking_api.php';
    var adSlots = {};
    var pageUrl = window.location.pathname;
    var templateName = getTemplateName();
    var deviceType = detectDevice();

    function getTemplateName() {
        // Use existing global variables from the page
        if (typeof pageSource !== 'undefined') {
            return pageSource.replace('.php', '').replace('/', '');
        }
        if (typeof eventCategory !== 'undefined') {
            return eventCategory;
        }
        if (typeof eventCategoryPage !== 'undefined') {
            return eventCategoryPage;
        }
        return 'unknown';
    }

    function detectDevice() {
        return window.innerWidth < 767 ? 'mobile' : 'desktop';
    }

    function trackAdSlot(slotId, slotName, status, errorMessage) {
        var startTime = performance.now();
        
        var data = {
            page_url: pageUrl,
            template_name: templateName,
            ad_slot: slotName,
            ad_slot_id: slotId,
            device_type: deviceType,
            status: status,
            error_message: errorMessage || '',
            load_time: 0
        };

        // Send tracking data
        sendTrackingData(data);
    }

    function sendTrackingData(data) {
        console.log('Sending tracking data:', data);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', trackingEndpoint, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 300) {
                console.log('✓ Ad tracking logged successfully:', xhr.responseText);
            } else {
                console.error('✗ Ad tracking failed:', xhr.status, xhr.statusText, xhr.responseText);
            }
        };
        xhr.onerror = function() {
            console.error('✗ Ad tracking network error');
        };
        
        var params = Object.keys(data).map(function(key) {
            return encodeURIComponent(key) + '=' + encodeURIComponent(data[key]);
        }).join('&');
        
        console.log('Sending to:', trackingEndpoint, 'with params:', params);
        xhr.send(params);
    }

    // Hook into Google Publisher Tag events
    function setupGPTTracking() {
        console.log('Setting up GPT tracking...');
        console.log('googletag defined:', typeof googletag !== 'undefined');
        
        if (typeof googletag !== 'undefined') {
            console.log('GPT found, queuing event listeners');
            googletag.cmd.push(function() {
                console.log('GPT ready, adding event listeners');
                
                // Track slot render ended
                googletag.pubads().addEventListener('slotRenderEnded', function(event) {
                    console.log('slotRenderEnded event fired:', event);
                    var slotId = event.slot.getSlotElementId();
                    var slotName = event.slot.getAdUnitPath();
                    var status = 'success';
                    var errorMessage = '';
                    
                    if (event.isEmpty) {
                        status = 'no_fill';
                        errorMessage = 'No ad returned for this slot';
                    } else if (!event.size) {
                        status = 'failed';
                        errorMessage = 'Ad size not defined';
                    }
                    
                    console.log('Tracking slot:', slotId, 'status:', status);
                    trackAdSlot(slotId, slotName, status, errorMessage);
                });

                // Track slot requested
                googletag.pubads().addEventListener('slotRequested', function(event) {
                    var slotId = event.slot.getSlotElementId();
                    var slotName = event.slot.getAdUnitPath();
                    adSlots[slotId] = { requested: true, startTime: performance.now() };
                });

                // Track slot response received
                googletag.pubads().addEventListener('slotResponseReceived', function(event) {
                    var slotId = event.slot.getSlotElementId();
                    if (adSlots[slotId]) {
                        adSlots[slotId].responseTime = performance.now() - adSlots[slotId].startTime;
                    }
                });

                // Track slot on load
                googletag.pubads().addEventListener('slotOnload', function(event) {
                    var slotId = event.slot.getSlotElementId();
                    var slotName = event.slot.getAdUnitPath();
                    var loadTime = adSlots[slotId] ? adSlots[slotId].responseTime : 0;
                    
                    var data = {
                        page_url: pageUrl,
                        template_name: templateName,
                        ad_slot: slotName,
                        ad_slot_id: slotId,
                        device_type: deviceType,
                        status: 'success',
                        error_message: '',
                        load_time: loadTime
                    };
                    
                    sendTrackingData(data);
                });
            });
        }
    }

    // Manual tracking for non-GPT ads
    function trackManualAd(slotId, slotName, element) {
        var status = 'failed';
        var errorMessage = 'Ad element not found or empty';
        
        if (element) {
            var iframe = element.querySelector('iframe');
            var img = element.querySelector('img');
            
            if (iframe && iframe.src) {
                status = 'success';
                errorMessage = '';
            } else if (img && img.src) {
                status = 'success';
                errorMessage = '';
            } else if (element.innerHTML.trim().length > 0) {
                status = 'success';
                errorMessage = '';
            }
        }
        
        trackAdSlot(slotId, slotName, status, errorMessage);
    }

    // Initialize tracking
    function init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
                setupGPTTracking();
            });
        } else {
            setupGPTTracking();
        }
    }

    return {
        init: init,
        trackAdSlot: trackAdSlot,
        trackManualAd: trackManualAd
    };
})();

// Auto-initialize
AdTracking.init();
